# Cirk - Equipment Rental App

A React Native app built with Expo for renting and sharing equipment between users.

## 🚀 Features

- User registration and profile management
- Equipment listing and browsing
- Booking system for equipment rentals
- Real-time data with Firebase Firestore
- Cross-platform (iOS, Android, Web)

## 🛠️ Tech Stack

- **Frontend**: React Native with Expo
- **Backend**: Firebase Firestore
- **Navigation**: Expo Router
- **Language**: JavaScript/TypeScript
- **State Management**: React Context/Hooks

## 📋 Prerequisites

Before running this project, make sure you have:

- Node.js (v16 or later)
- npm or yarn
- Expo CLI (`npm install -g @expo/cli`)
- Firebase project setup

## 🔧 Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd cirk-1
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
   - Copy `.env.example` to `.env`
   - Add your Firebase configuration values

4. Start the development server:
```bash
npm start
```

## 📱 Running the App

- **iOS Simulator**: Press `i` in the terminal
- **Android Emulator**: Press `a` in the terminal
- **Web**: Press `w` in the terminal
- **Physical Device**: Scan the QR code with Expo Go app

## 🔥 Firebase Setup

1. Create a Firebase project at [Firebase Console](https://console.firebase.google.com)
2. Enable Firestore Database
3. Copy your Firebase config to `.env` file:
```env
API_KEY=your_api_key
AUTH_DOMAIN=your_project.firebaseapp.com
PROJECT_ID=your_project_id
STORAGE_BUCKET=your_project.appspot.com
MESSAGING_SENDER_ID=your_sender_id
APP_ID=your_app_id
MEASUREMENT_ID=your_measurement_id
```

## 📂 Project Structure

```
app/
├── (tabs)/           # Tab navigation screens
├── conf/             # Configuration files
│   └── firebaseConfig.js
├── services/         # API and Firebase services
│   └── firestoreService.js
├── types/            # TypeScript type definitions
└── utils/            # Utility functions
```

## 🚀 Available Scripts

- `npm start` - Start the Expo development server
- `npm run android` - Run on Android
- `npm run ios` - Run on iOS
- `npm run web` - Run on web
- `npm run lint` - Run ESLint

## 🤝 Contributing

1. Fork the project
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request