import { Timestamp } from 'firebase/firestore';
import React, { useState } from 'react';
import {
  Alert,
  Button,
  Modal,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';
import { validateEquipmentForm } from '../app/helpers/equip-form-validation';
import { addEquipment } from '../app/services/firestoreService';
import { Equipment } from '../app/types/schemas';
import { FormInput } from './form-input';

interface EquipmentFormProps {
  visible: boolean;
  onClose: () => void;
}
type EquipmentFormData = Pick<Equipment, 'title' | 'description' | 'category' | 'pricePerDay' | 'location'>;
export const EquipmentForm: React.FC<EquipmentFormProps> = ({ visible, onClose }) => {
  const [formData, setFormData] = useState<EquipmentFormData>({
    title: '',
    description: '',
    category: '',
    pricePerDay: 0,
    location: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: keyof EquipmentFormData, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      category: '',
      pricePerDay: 0,
      location: ''
    });
  };

  const handleSubmit = async () => {
    if (
      !validateEquipmentForm({
        id: '',
        ownerId: 'owner_user_123',
        title: formData.title,
        description: formData.description,
        category: formData.category,
        pricePerDay: Number(formData.pricePerDay),
        imageUrls: ['https://placehold.co/600x400/A8D8B9/333?text=Equipment'],
        location: formData.location,
        availability: true,
        listedAt: Timestamp.now()
      })
    )
      return;

    setIsSubmitting(true);
    try {
      const equipmentData = {
        ownerId: "owner_user_123", // In a real app, this would come from authenticated user
        title: formData.title,
        description: formData.description,
        category: formData.category,
        pricePerDay: Number(formData.pricePerDay),
        imageUrls: ["https://placehold.co/600x400/A8D8B9/333?text=Equipment"], // Placeholder image
        location: formData.location,
        availability: true
      };

      const equipmentId = await addEquipment(equipmentData);
      
      if (equipmentId) {
        Alert.alert('Success', 'Equipment added successfully!', [
          {
            text: 'OK',
            onPress: () => {
              onClose();
              resetForm();
            }
          }
        ]);
      } else {
        Alert.alert('Error', 'Failed to add equipment. Please try again.');
      }
    } catch (error) {
      console.error('Error submitting form:', error);
      Alert.alert('Error', 'An unexpected error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    onClose();
    resetForm();
  };

  return (
    <Modal
      animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={handleCancel}
    >
      <SafeAreaView style={styles.modalContainer}>
        <View style={styles.modalHeader}>
          <Text style={styles.modalTitle}>Add New Equipment</Text>
          <TouchableOpacity onPress={handleCancel} style={styles.cancelButton}>
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.formContainer} showsVerticalScrollIndicator={false}>
          <FormInput
            label="Title"
            value={formData.title}
            onChangeText={(value) => handleInputChange('title', value)}
            placeholder="e.g., Camping Tent, Professional Camera"
            required
          />

          <FormInput
            label="Description"
            value={formData.description}
            onChangeText={(value) => handleInputChange('description', value)}
            placeholder="Describe your equipment, its condition, and any special features"
            multiline
            numberOfLines={4}
            required
          />

          <FormInput
            label="Category"
            value={formData.category}
            onChangeText={(value) => handleInputChange('category', value)}
            placeholder="e.g., Camping, Photography, Sports"
            required
          />

          <FormInput
            label="Price per Day"
            value={formData.pricePerDay.toString()}
            onChangeText={(value) => handleInputChange('pricePerDay', value)}
            placeholder="150"
            keyboardType="numeric"
            required
          />

          <FormInput
            label="Location"
            value={formData.location}
            onChangeText={(value) => handleInputChange('location', value)}
            placeholder="e.g., Burnaby, BC"
            required
          />

          <View style={styles.submitButtonContainer}>
            <Button
              title={isSubmitting ? "Adding Equipment..." : "Add Equipment"}
              onPress={handleSubmit}
              color="#28a745"
              disabled={isSubmitting}
            />
          </View>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: '#f4f4f8',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  cancelButton: {
    padding: 8,
  },
  cancelButtonText: {
    color: '#007AFF',
    fontSize: 16,
  },
  formContainer: {
    flex: 1,
    padding: 20,
  },
  submitButtonContainer: {
    marginTop: 20,
    marginBottom: 40,
    borderRadius: 8,
    overflow: 'hidden',
  },
});