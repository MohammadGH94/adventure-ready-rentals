import React, { useState } from 'react';
import { ActivityIndicator, Alert, Platform, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { signInWithGoogle } from '../app/services/sign-in-platform-detect';

export function GoogleSignInButton({ onSuccess }: { onSuccess?: () => void }) {
  const [loading, setLoading] = useState(false);

  const handlePress = async () => {
    setLoading(true);
    try {
      console.log(`Starting Google sign-in on ${Platform.OS}...`);
      const result = await signInWithGoogle();
      
      if (result.user) {
        Alert.alert('Success', 'Successfully signed in with Google!');
        onSuccess?.();
      } else if (result.error) {
        Alert.alert('Error', result.error);
      }
    } catch (error: any) {
      console.error('Google sign-in button error:', error);
      Alert.alert('Error', error.message || 'Google sign-in failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <TouchableOpacity style={styles.button} onPress={handlePress} disabled={loading}>
      <View style={styles.buttonContent}>
        {loading ? (
          <ActivityIndicator color="#fff" />
        ) : (
          <>
            <Text style={styles.buttonText}>
              Continue with Google {Platform.OS === 'web' ? '(Popup)' : ''}
            </Text>
          </>
        )}
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: '#4285F4',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    marginVertical: 10,
  },
  buttonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});