import React, { useState } from 'react';
import {
  Alert,
  Button,
  Modal,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import { SignUpData, signUpWithEmail } from '../app/services/auth';
import { FormInput } from './form-input';
import { GoogleSignInButton } from './google-sign-in-btn';

interface SignUpFormProps {
  visible: boolean;
  onClose: () => void;
  onSwitchToSignIn: () => void;
}

const createInitialFormState = (): SignUpData => ({
  email: '',
  password: '',
  firstName: '',
  lastName: '',
  userType: 'individual',
  dateOfBirth: '',
  phoneNumber: '',
  profileBio: '',
  city: '',
  stateProvince: '',
  country: '',
  postalCode: '',
  governmentIdImage: null,
  paymentMethodIds: [],
  voidCheque: null,
  institutionNumber: null,
  transitNumber: null,
  accountNumber: null,
  payoutMethodId: null,
  businessName: null,
  businessLicense: null,
  taxId: null,
  profileImageUrl: null,
});

const toNullable = (value?: string | null) => {
  if (value === null || value === undefined) {
    return null;
  }

  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
};

export const SignUpForm: React.FC<SignUpFormProps> = ({
  visible,
  onClose,
  onSwitchToSignIn,
}) => {
  const [formData, setFormData] = useState<SignUpData>(() => createInitialFormState());
  const [paymentMethodIdsInput, setPaymentMethodIdsInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Partial<Record<keyof SignUpData, string>>>({});

  const handleStringChange = <K extends keyof SignUpData>(field: K) => (value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value as SignUpData[K],
    }));
    setErrors((prev) => {
      if (!prev[field]) {
        return prev;
      }
      const updated = { ...prev };
      delete updated[field];
      return updated;
    });
  };

  const handleUserTypeChange = (type: SignUpData['userType']) => {
    setFormData((prev) => ({
      ...prev,
      userType: type,
    }));
  };

  const handlePaymentMethodsChange = (value: string) => {
    setPaymentMethodIdsInput(value);
    const ids = value
      .split(',')
      .map((id) => id.trim())
      .filter((id) => id.length > 0);
    setFormData((prev) => ({
      ...prev,
      paymentMethodIds: ids,
    }));
  };

  const resetForm = () => {
    setFormData(createInitialFormState());
    setPaymentMethodIdsInput('');
    setErrors({});
  };

  const requiredFields: Array<keyof SignUpData> = [
    'email',
    'password',
    'firstName',
    'lastName',
    'dateOfBirth',
    'phoneNumber',
    'profileBio',
    'city',
    'stateProvince',
    'country',
    'postalCode'
  ];

  const REQUIRED_MESSAGES: Partial<Record<keyof SignUpData, string>> = {
    email: 'Email is required',
    password: 'Password is required',
    firstName: 'First name is required',
    lastName: 'Last name is required',
    dateOfBirth: 'Date of birth is required',
    phoneNumber: 'Phone number is required',
    profileBio: 'Tell renters a bit about yourself',
    city: 'City is required',
    stateProvince: 'State or province is required',
    country: 'Country is required',
    postalCode: 'Postal code is required',
  };

  const validateFields = (data: SignUpData): Partial<Record<keyof SignUpData, string>> => {
    const nextErrors: Partial<Record<keyof SignUpData, string>> = {};

    requiredFields.forEach((field) => {
      const value = data[field];
      if (typeof value === 'string') {
        const trimmed = value.trim();
        if (!trimmed) {
          nextErrors[field] = REQUIRED_MESSAGES[field] ?? 'This field is required';
        }
      }
    });

    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      nextErrors.email = 'Enter a valid email address';
    }

    if (data.password && data.password.length < 6) {
      nextErrors.password = 'Password must be at least 6 characters';
    }

    return nextErrors;
  };

  const handleSubmit = async () => {
    const submissionData: SignUpData = {
      ...formData,
      email: formData.email.trim(),
      firstName: formData.firstName.trim(),
      lastName: formData.lastName.trim(),
      dateOfBirth: formData.dateOfBirth.trim(),
      phoneNumber: formData.phoneNumber.trim(),
      profileBio: formData.profileBio.trim(),
      city: formData.city.trim(),
      stateProvince: formData.stateProvince.trim(),
      country: formData.country.trim(),
      postalCode: formData.postalCode.trim(),
      governmentIdImage: toNullable(formData.governmentIdImage),
      voidCheque: toNullable(formData.voidCheque),
      institutionNumber: toNullable(formData.institutionNumber),
      transitNumber: toNullable(formData.transitNumber),
      accountNumber: toNullable(formData.accountNumber),
      payoutMethodId: toNullable(formData.payoutMethodId),
      businessName: toNullable(formData.businessName),
      businessLicense: toNullable(formData.businessLicense),
      taxId: toNullable(formData.taxId),
      profileImageUrl: toNullable(formData.profileImageUrl),
      paymentMethodIds: formData.paymentMethodIds.map((id) => id.trim()).filter((id) => id.length > 0),
    };

    const validationErrors = validateFields(submissionData);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      Alert.alert('Almost there!', 'Please review the highlighted fields.');
      return;
    }

    setErrors({});
    setIsSubmitting(true);
    try {
      await signUpWithEmail(submissionData);
      Alert.alert('Verify your email', 'We just sent a verification link to your inbox. Confirm it to unlock all features.', [
        {
          text: 'OK',
          onPress: () => {
            onClose();
            resetForm();
          },
        },
      ]);
    } catch (error: any) {
      Alert.alert('Error', error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    onClose();
    resetForm();
  };

  const handleGoogleSuccess = () => {
    Alert.alert('Success', 'Signed up with Google successfully!', [
      {
        text: 'OK',
        onPress: () => {
          onClose();
          resetForm();
        },
      },
    ]);
  };

  return (
    <Modal
      animationType="slide"
      transparent={false}
      visible={visible}
      onRequestClose={handleCancel}
    >
      <SafeAreaView style={styles.modalContainer}>
        <View style={styles.modalHeader}>
          <Text style={styles.modalTitle}>Sign Up</Text>
          <TouchableOpacity onPress={handleCancel} style={styles.cancelButton}>
            <Text style={styles.cancelButtonText}>Cancel</Text>
          </TouchableOpacity>
        </View>

        <ScrollView style={styles.formContainer} showsVerticalScrollIndicator={false}>
          <GoogleSignInButton onSuccess={handleGoogleSuccess} />

          <View style={styles.dividerContainer}>
            <View style={styles.dividerLine} />
            <Text style={styles.dividerText}>OR</Text>
            <View style={styles.dividerLine} />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Account Details</Text>

            <View style={styles.userTypeContainer}>
              <Text style={styles.labelText}>User Type *</Text>
              <View style={styles.userTypeOptions}>
                {(['individual', 'business'] as const).map((type) => (
                  <TouchableOpacity
                    key={type}
                    style={[
                      styles.userTypeOption,
                      formData.userType === type && styles.userTypeOptionActive,
                    ]}
                    onPress={() => handleUserTypeChange(type)}
                  >
                    <Text
                      style={[
                        styles.userTypeOptionText,
                        formData.userType === type && styles.userTypeOptionTextActive,
                      ]}
                    >
                      {type === 'individual' ? 'Individual' : 'Business'}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <FormInput
              label="Email"
              value={formData.email}
              onChangeText={handleStringChange('email')}
              placeholder="your@email.com"
              keyboardType="email-address"
              required
              errorMessage={errors.email}
            />

            <FormInput
              label="Password"
              value={formData.password}
              onChangeText={handleStringChange('password')}
              placeholder="At least 6 characters"
              required
              secureTextEntry
              errorMessage={errors.password}
            />

          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Personal Information</Text>

            <FormInput
              label="First Name"
              value={formData.firstName}
              onChangeText={handleStringChange('firstName')}
              placeholder="e.g., Jane"
              required
              errorMessage={errors.firstName}
            />

            <FormInput
              label="Last Name"
              value={formData.lastName}
              onChangeText={handleStringChange('lastName')}
              placeholder="e.g., Doe"
              required
              errorMessage={errors.lastName}
            />

            <FormInput
              label="Date of Birth"
              value={formData.dateOfBirth}
              onChangeText={handleStringChange('dateOfBirth')}
              placeholder="YYYY-MM-DD"
              required
              errorMessage={errors.dateOfBirth}
            />

            <FormInput
              label="Phone Number"
              value={formData.phoneNumber}
              onChangeText={handleStringChange('phoneNumber')}
              placeholder="e.g., +1 604 555 1234"
              required
              errorMessage={errors.phoneNumber}
            />

            <FormInput
              label="Profile Bio"
              value={formData.profileBio}
              onChangeText={handleStringChange('profileBio')}
              placeholder="Tell us about yourself"
              multiline
              numberOfLines={4}
              required
              errorMessage={errors.profileBio}
            />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Address</Text>

            <FormInput
              label="City"
              value={formData.city}
              onChangeText={handleStringChange('city')}
              placeholder="e.g., Vancouver"
              required
              errorMessage={errors.city}
            />

            <FormInput
              label="State / Province"
              value={formData.stateProvince}
              onChangeText={handleStringChange('stateProvince')}
              placeholder="e.g., British Columbia"
              required
              errorMessage={errors.stateProvince}
            />

            <FormInput
              label="Country"
              value={formData.country}
              onChangeText={handleStringChange('country')}
              placeholder="e.g., Canada"
              required
              errorMessage={errors.country}
            />

            <FormInput
              label="Postal Code"
              value={formData.postalCode}
              onChangeText={handleStringChange('postalCode')}
              placeholder="e.g., V5K 0A1"
              required
              errorMessage={errors.postalCode}
            />
          </View>

          {formData.userType === 'business' && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Business Details</Text>

              <FormInput
                label="Business Name"
                value={formData.businessName ?? ''}
                onChangeText={handleStringChange('businessName')}
                placeholder="e.g., Outdoor Rentals Inc."
              />

              <FormInput
                label="Business License"
                value={formData.businessLicense ?? ''}
                onChangeText={handleStringChange('businessLicense')}
                placeholder="License number"
              />

              <FormInput
                label="Tax ID"
                value={formData.taxId ?? ''}
                onChangeText={handleStringChange('taxId')}
                placeholder="Tax identification number"
              />
            </View>
          )}

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Verification & Compliance</Text>

            <FormInput
              label="Government ID Image URL"
              value={formData.governmentIdImage ?? ''}
              onChangeText={handleStringChange('governmentIdImage')}
              placeholder="Temporary storage location"
            />

            <FormInput
              label="Void Cheque URL"
              value={formData.voidCheque ?? ''}
              onChangeText={handleStringChange('voidCheque')}
              placeholder="Upload location or link"
            />

            <FormInput
              label="Institution Number"
              value={formData.institutionNumber ?? ''}
              onChangeText={handleStringChange('institutionNumber')}
              placeholder="e.g., 001"
            />

            <FormInput
              label="Transit Number"
              value={formData.transitNumber ?? ''}
              onChangeText={handleStringChange('transitNumber')}
              placeholder="e.g., 00011"
            />

            <FormInput
              label="Account Number"
              value={formData.accountNumber ?? ''}
              onChangeText={handleStringChange('accountNumber')}
              placeholder="Bank account number"
            />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Payments & Payouts</Text>

            <FormInput
              label="Payment Method IDs"
              value={paymentMethodIdsInput}
              onChangeText={handlePaymentMethodsChange}
              placeholder="Comma separated list of payment IDs"
            />

            <FormInput
              label="Payout Method ID"
              value={formData.payoutMethodId ?? ''}
              onChangeText={handleStringChange('payoutMethodId')}
              placeholder="Identifier for payout method"
            />
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Profile</Text>

            <FormInput
              label="Profile Image URL"
              value={formData.profileImageUrl ?? ''}
              onChangeText={handleStringChange('profileImageUrl')}
              placeholder="Link to profile image"
            />
          </View>

          <View style={styles.submitButtonContainer}>
            <Button
              title={isSubmitting ? 'Creating Account...' : 'Sign Up'}
              onPress={handleSubmit}
              color="#28a745"
              disabled={isSubmitting}
            />
          </View>

          <TouchableOpacity style={styles.switchButton} onPress={onSwitchToSignIn}>
            <Text style={styles.switchButtonText}>Already have an account? Sign In</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    backgroundColor: '#f4f4f8',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  cancelButton: {
    padding: 8,
  },
  cancelButtonText: {
    color: '#007AFF',
    fontSize: 16,
  },
  formContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  dividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: '#e0e0e0',
  },
  dividerText: {
    marginHorizontal: 15,
    color: '#666',
    fontSize: 14,
  },
  section: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    shadowColor: '#00000010',
    shadowOpacity: 0.08,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 6,
    elevation: 1,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 12,
  },
  userTypeContainer: {
    marginBottom: 16,
  },
  labelText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  userTypeOptions: {
    flexDirection: 'row',
    gap: 12,
  },
  userTypeOption: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#d1d5db',
    alignItems: 'center',
  },
  userTypeOptionActive: {
    borderColor: '#2563eb',
    backgroundColor: '#dbeafe',
  },
  userTypeOptionText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1f2937',
  },
  userTypeOptionTextActive: {
    color: '#1d4ed8',
  },
  submitButtonContainer: {
    marginTop: 12,
    marginBottom: 24,
    borderRadius: 8,
    overflow: 'hidden',
  },
  switchButton: {
    alignItems: 'center',
    paddingVertical: 12,
    marginBottom: 32,
  },
  switchButtonText: {
    color: '#007AFF',
    fontSize: 16,
  },
});
