import React, { useState } from 'react';
import {
    Alert,
    Button,
    SafeAreaView,
    StyleSheet,
    Text,
    View
} from 'react-native';
import { confirmPasswordResetWithCode } from '../app/services/password-reset';
import { FormInput } from './form-input';

interface PasswordResetScreenProps {
  resetCode: string; // From URL parameters
  onSuccess: () => void;
  onCancel: () => void;
}

export const PasswordResetScreen: React.FC<PasswordResetScreenProps> = ({ 
  resetCode, 
  onSuccess, 
  onCancel 
}) => {
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validateForm = (): boolean => {
    if (!newPassword.trim()) {
      Alert.alert('Error', 'New password is required');
      return false;
    }
    if (newPassword.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters long');
      return false;
    }
    if (newPassword !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return false;
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      const result = await confirmPasswordResetWithCode(resetCode, newPassword);
      
      if (result.success) {
        Alert.alert(
          'Password Reset Successful', 
          'Your password has been reset successfully. You can now sign in with your new password.',
          [{ text: 'OK', onPress: onSuccess }]
        );
      } else {
        Alert.alert('Error', result.error || 'Failed to reset password');
      }
    } catch (error: any) {
      Alert.alert('Error', error.message || 'An unexpected error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Set New Password</Text>
        <Text style={styles.description}>
          Enter your new password below.
        </Text>

        <FormInput
          label="New Password"
          value={newPassword}
          onChangeText={setNewPassword}
          placeholder="At least 6 characters"
          required
          secureTextEntry
        />

        <FormInput
          label="Confirm New Password"
          value={confirmPassword}
          onChangeText={setConfirmPassword}
          placeholder="Confirm your new password"
          required
          secureTextEntry
        />

        <View style={styles.buttonContainer}>
          <Button
            title={isSubmitting ? "Resetting..." : "Reset Password"}
            onPress={handleSubmit}
            color="#28a745"
            disabled={isSubmitting}
          />
        </View>

        <View style={styles.buttonContainer}>
          <Button
            title="Cancel"
            onPress={onCancel}
            color="#6c757d"
          />
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f4f8',
  },
  content: {
    flex: 1,
    padding: 20,
    justifyContent: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 10,
  },
  description: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 30,
    lineHeight: 22,
  },
  buttonContainer: {
    marginTop: 15,
    borderRadius: 8,
    overflow: 'hidden',
  },
});