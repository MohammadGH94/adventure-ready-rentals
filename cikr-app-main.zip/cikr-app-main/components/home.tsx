import React from 'react';
import { Button, StyleSheet, Text, View } from 'react-native';

interface HomeScreenProps {
  onAddEquipment: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ onAddEquipment }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Cirk Equipment Rental</Text>
      <Text style={styles.subtitle}>Share your gear with others</Text>
      
      <View style={styles.buttonContainer}>
        <Button
          title="Add New Equipment"
          onPress={onAddEquipment}
          color="#007AFF"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
    color: '#333',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: 30,
    textAlign: 'center',
  },
  buttonContainer: {
    width: '80%',
    borderRadius: 8,
    overflow: 'hidden',
  },
});