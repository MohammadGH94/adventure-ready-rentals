import {
  createUserWithEmailAndPassword,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  User
} from 'firebase/auth';
import { auth } from '../conf/firebaseConfig';
import { addUser, buildUserProfilePayload } from './firestoreService';

export interface AuthUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  emailVerified: boolean;
}

export interface SignUpData {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  userType: 'individual' | 'business';
  dateOfBirth: string;
  phoneNumber: string;
  profileBio: string;
  city: string;
  stateProvince: string;
  country: string;
  postalCode: string;
  governmentIdImage?: string | null;
  paymentMethodIds: string[];
  voidCheque?: string | null;
  institutionNumber?: string | null;
  transitNumber?: string | null;
  accountNumber?: string | null;
  payoutMethodId?: string | null;
  businessName?: string | null;
  businessLicense?: string | null;
  taxId?: string | null;
  profileImageUrl?: string | null;
}

export interface SignInData {
  email: string;
  password: string;
}

/**
 * Sign up with email and password
 */
export const signUpWithEmail = async (userData: SignUpData): Promise<AuthUser | null> => {
  try {
    const userCredential = await createUserWithEmailAndPassword(
      auth,
      userData.email,
      userData.password
    );
    
    const user = userCredential.user;
    const displayName = `${userData.firstName} ${userData.lastName}`.trim();
    
    // Update user profile with display name
    await updateProfile(user, {
      displayName
    });

    try {
      await sendEmailVerification(user);
    } catch (verificationError) {
      console.error('Error sending verification email:', verificationError);
    }

    // Create user document in Firestore
    await addUser(
      user.uid,
      buildUserProfilePayload({
        name: displayName,
        email: userData.email,
        userType: userData.userType,
        firstName: userData.firstName,
        lastName: userData.lastName,
        dateOfBirth: userData.dateOfBirth,
        phoneNumber: userData.phoneNumber,
        profileBio: userData.profileBio,
        city: userData.city,
        stateProvince: userData.stateProvince,
        country: userData.country,
        postalCode: userData.postalCode,
        governmentIdImage: userData.governmentIdImage ?? null,
        isVerified: false,
        paymentMethodIds: userData.paymentMethodIds,
        voidCheque: userData.voidCheque ?? null,
        institutionNumber: userData.institutionNumber ?? null,
        transitNumber: userData.transitNumber ?? null,
        accountNumber: userData.accountNumber ?? null,
        payoutMethodId: userData.payoutMethodId ?? null,
        businessName: userData.businessName ?? null,
        businessLicense: userData.businessLicense ?? null,
        taxId: userData.taxId ?? null,
        profileImageUrl: userData.profileImageUrl ?? user.photoURL ?? undefined,
      })
    );

    return {
      uid: user.uid,
      email: user.email,
      displayName,
      photoURL: user.photoURL,
      emailVerified: user.emailVerified
    };
  } catch (error: any) {
    console.error('Error signing up:', error);
    throw new Error(error.message);
  }
};

/**
 * Sign in with email and password
 */
export const signInWithEmail = async (userData: SignInData): Promise<AuthUser | null> => {
  try {
    const userCredential = await signInWithEmailAndPassword(
      auth,
      userData.email,
      userData.password
    );
    
    const user = userCredential.user;
    
    return {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL,
      emailVerified: user.emailVerified
    };
  } catch (error: any) {
    console.error('Error signing in:', error);
    throw new Error(error.message);
  }
};

/**
 * Sign out
 */
export const signOutUser = async (): Promise<void> => {
  try {
    await signOut(auth);
  } catch (error: any) {
    console.error('Error signing out:', error);
    throw new Error(error.message);
  }
};

/**
 * Get current user
 */
export const getCurrentUser = (): User | null => {
  return auth.currentUser;
};

export const sendVerificationEmail = async (): Promise<void> => {
  const currentUser = auth.currentUser;

  if (!currentUser) {
    throw new Error('No authenticated user found. Please sign in again.');
  }

  if (currentUser.emailVerified) {
    throw new Error('Your email is already verified.');
  }

  await sendEmailVerification(currentUser);
};
