import { GoogleAuthProvider, signInWithPopup, signInWithRedirect } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { Platform } from 'react-native';
import { auth, db } from '../conf/firebaseConfig';
import { addUser, buildUserProfilePayload } from './firestoreService';

const parseName = (displayName?: string | null) => {
  if (!displayName) {
    return { firstName: '', lastName: '' };
  }

  const parts = displayName.trim().split(/\s+/);
  const firstName = parts.shift() ?? '';
  const lastName = parts.join(' ');

  return { firstName, lastName };
};

export interface GoogleSignInResult {
  user: any | null;
  error?: string;
}

export async function signInWithGoogleWeb(): Promise<GoogleSignInResult> {
  try {
    if (Platform.OS !== 'web') {
      throw new Error('This method is only for web platform');
    }

    console.log('Starting Google sign-in for web...');

    // Create Google Auth Provider
    const provider = new GoogleAuthProvider();
    provider.addScope('profile');
    provider.addScope('email');

    // Use popup for web (better UX than redirect)
    let result;
    try {
      result = await signInWithPopup(auth, provider);
    } catch (popupError: any) {
      // Fallback to redirect if popup is blocked
      console.log('Popup blocked, trying redirect...', popupError);
      result = await signInWithRedirect(auth, provider);
    }

    const user = result.user;
    console.log('Google sign-in successful:', user.uid);

    // Check if user document exists in Firestore, create if not
    const userDoc = await getDoc(doc(db, 'users', user.uid));
    if (!userDoc.exists()) {
      console.log('Creating new user document in Firestore...');
      const { firstName, lastName } = parseName(user.displayName);
      await addUser(
        user.uid,
        buildUserProfilePayload({
          email: user.email || '',
          userType: 'individual',
          firstName,
          lastName,
          profileBio: '',
          dateOfBirth: '',
          phoneNumber: '',
          city: '',
          stateProvince: '',
          country: '',
          postalCode: '',
          paymentMethodIds: [],
          isVerified: false,
          profileImageUrl: user.photoURL || undefined,
          name: user.displayName || undefined
        })
      );
    }

    return {
      user: {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL
      }
    };
  } catch (error: any) {
    console.error('Google sign-in error:', error);
    
    // Handle specific error codes
    if (error.code === 'auth/popup-closed-by-user') {
      return { user: null, error: 'Sign-in was cancelled' };
    } else if (error.code === 'auth/popup-blocked') {
      return { user: null, error: 'Popup was blocked by browser. Please allow popups and try again.' };
    } else {
      return { user: null, error: error.message || 'Google sign-in failed' };
    }
  }
}
