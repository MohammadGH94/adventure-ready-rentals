import { addDoc, collection, doc, getDoc, setDoc, Timestamp } from 'firebase/firestore';
import { db } from '../conf/firebaseConfig.js';
import { Booking, Equipment, User } from '../types/schemas';

type UserWithoutMeta = Omit<User, 'id' | 'createdAt'>;

export const buildUserProfilePayload = (
  overrides: Partial<UserWithoutMeta> = {}
): UserWithoutMeta => ({
  email: '',
  userType: 'individual',
  firstName: '',
  lastName: '',
  dateOfBirth: '',
  phoneNumber: '',
  profileBio: '',
  city: '',
  stateProvince: '',
  country: '',
  postalCode: '',
  governmentIdImage: null,
  isVerified: false,
  paymentMethodIds: [],
  voidCheque: null,
  institutionNumber: null,
  transitNumber: null,
  accountNumber: null,
  payoutMethodId: null,
  businessName: null,
  businessLicense: null,
  taxId: null,
  profileImageUrl: undefined,
  name: undefined,
  ...overrides,
});

/**
 * Adds or updates a user document in the 'users' collection.
 * @param {string} userId - The user's unique ID from Firebase Auth.
 * @param {Omit<User, 'id' | 'createdAt'>} userData - User details
 * @returns {Promise<void>}
 */
export const addUser = async (userId: string, userData: UserWithoutMeta): Promise<void> => {
  try {
    const userRef = doc(db, 'users', userId);
    await setDoc(userRef, {
      ...buildUserProfilePayload(userData),
      createdAt: Timestamp.now()
    });
    console.log("User document created/updated for ID: ", userId);
  } catch (e) {
    console.error("Error adding user document: ", e);
  }
};

/**
 * Fetches a user document by ID from Firestore.
 * @param {string} userId - The user's unique ID from Firebase Auth.
 * @returns {Promise<User | null>} - The user document or null if it doesn't exist.
 */
export const getUser = async (userId: string): Promise<User | null> => {
  try {
    const userRef = doc(db, 'users', userId);
    const userSnapshot = await getDoc(userRef);

    if (!userSnapshot.exists()) {
      return null;
    }

    const data = userSnapshot.data();
    const profile = buildUserProfilePayload(data as Partial<UserWithoutMeta>);

    return {
      id: userSnapshot.id,
      ...profile,
      createdAt: data.createdAt ?? Timestamp.now()
    };
  } catch (error) {
    console.error('Error fetching user document: ', error);
    return null;
  }
};

/**
 * Adds a new piece of equipment to the 'equipment' collection.
 * @param {Omit<Equipment, 'id' | 'listedAt'>} equipmentData - Equipment details
 * @returns {Promise<string|null>} - The ID of the newly created document or null on error.
 */
export const addEquipment = async (equipmentData: Omit<Equipment, 'id' | 'listedAt'>): Promise<string | null> => {
  try {
    const docRef = await addDoc(collection(db, 'equipment'), {
        ...equipmentData,
        listedAt: Timestamp.now()
    });
    console.log("Equipment document written with ID: ", docRef.id);
    return docRef.id;
  } catch (e) {
    console.error("Error adding equipment document: ", e);
    return null;
  }
};

/**
 * Adds a new booking to the 'bookings' collection.
 * @param {Omit<Booking, 'id' | 'createdAt'>} bookingData - Booking details
 * @returns {Promise<string|null>} - The ID of the newly created document or null on error.
 */
export const addBooking = async (bookingData: Omit<Booking, 'id' | 'createdAt'>): Promise<string | null> => {
  try {
    const docRef = await addDoc(collection(db, 'bookings'), {
        ...bookingData,
        createdAt: Timestamp.now()
    });
    console.log("Booking document written with ID: ", docRef.id);
    return docRef.id;
  } catch (e) {
    console.error("Error adding booking document: ", e);
    return null;
  }
};
