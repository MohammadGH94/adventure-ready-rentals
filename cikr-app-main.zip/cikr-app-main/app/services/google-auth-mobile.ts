import * as AuthSession from 'expo-auth-session';
import Constants from 'expo-constants';
import * as WebBrowser from 'expo-web-browser';
import { GoogleAuthProvider, signInWithCredential } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db } from '../conf/firebaseConfig';
import { addUser, buildUserProfilePayload } from './firestoreService';

const parseName = (displayName?: string | null) => {
  if (!displayName) {
    return { firstName: '', lastName: '' };
  }

  const parts = displayName.trim().split(/\s+/);
  const firstName = parts.shift() ?? '';
  const lastName = parts.join(' ');

  return { firstName, lastName };
};

WebBrowser.maybeCompleteAuthSession();

export interface GoogleSignInResult {
  user: any | null;
  error?: string;
}

export async function signInWithGoogleMobile(): Promise<GoogleSignInResult> {
  try {
    const clientId = Constants.expoConfig?.extra?.GOOGLE_WEB_CLIENT_ID;
    
    if (!clientId) {
      throw new Error('Google Web Client ID not found in configuration');
    }

    const redirectUri = AuthSession.makeRedirectUri();
    
    // Use AuthRequest with promptAsync for mobile
    const request = new AuthSession.AuthRequest({
      clientId,
      scopes: ['openid', 'profile', 'email'],
      responseType: AuthSession.ResponseType.IdToken,
      redirectUri,
    });
    
    const result = await request.promptAsync({
      authorizationEndpoint: 'https://accounts.google.com/o/oauth2/v2/auth',
    });

    if (result.type === 'success' && result.params.id_token) {
      const credential = GoogleAuthProvider.credential(result.params.id_token);
      const userCredential = await signInWithCredential(auth, credential);
      const user = userCredential.user;

      // Check if user document exists in Firestore, create if not
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (!userDoc.exists()) {
        const { firstName, lastName } = parseName(user.displayName);
        await addUser(
          user.uid,
          buildUserProfilePayload({
            email: user.email || '',
            userType: 'individual',
            firstName,
            lastName,
            profileBio: '',
            dateOfBirth: '',
            phoneNumber: '',
            city: '',
            stateProvince: '',
            country: '',
            postalCode: '',
            paymentMethodIds: [],
            isVerified: false,
            profileImageUrl: user.photoURL || undefined,
            name: user.displayName || undefined
          })
        );
      }

      return {
        user: {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL
        }
      };
    } else {
      return { user: null, error: 'Google sign-in cancelled or failed' };
    }
  } catch (error: any) {
    console.error('Google sign-in error:', error);
    return { user: null, error: error.message || 'Google sign-in failed' };
  }
}
