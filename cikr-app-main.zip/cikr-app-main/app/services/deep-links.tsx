import * as Linking from 'expo-linking';
import { useEffect, useState } from 'react';

export interface DeepLinkData {
  url: string | null;
  resetCode?: string;
  mode?: string;
}

/**
 * Custom hook to handle deep links
 */
export const useDeepLink = () => {
  const [deepLinkData, setDeepLinkData] = useState<DeepLinkData>({ url: null });

  useEffect(() => {
    // Handle initial URL when app opens from a link
    const getInitialURL = async () => {
      const initialUrl = await Linking.getInitialURL();
      if (initialUrl) {
        handleDeepLink(initialUrl);
      }
    };

    // Handle URLs when app is already open
    const subscription = Linking.addEventListener('url', (event) => {
      handleDeepLink(event.url);
    });

    getInitialURL();

    return () => subscription?.remove();
  }, []);

  const handleDeepLink = (url: string) => {
    console.log('Deep link received:', url);
    
    try {
      // Parse the URL
      const parsedUrl = Linking.parse(url);
      console.log('Parsed URL:', parsedUrl);

      // Check if it's a Firebase password reset link
      if (parsedUrl.hostname === 'cirk-a651e.firebaseapp.com' || 
          parsedUrl.hostname === 'localhost' ||
          parsedUrl.path?.includes('__/auth/action')) {
        
        // Extract query parameters
        const queryParams = parsedUrl.queryParams;
        const mode = queryParams?.mode as string;
        const oobCode = queryParams?.oobCode as string;

        if (mode === 'resetPassword' && oobCode) {
          setDeepLinkData({
            url,
            resetCode: oobCode,
            mode: 'resetPassword'
          });
        }
      }
      
      // Handle custom scheme links (cirk://reset-password?code=...)
      if (parsedUrl.scheme === 'cirk' && parsedUrl.hostname === 'reset-password') {
        const resetCode = parsedUrl.queryParams?.code as string;
        if (resetCode) {
          setDeepLinkData({
            url,
            resetCode,
            mode: 'resetPassword'
          });
        }
      }
    } catch (error) {
      console.error('Error parsing deep link:', error);
    }
  };

  const clearDeepLink = () => {
    setDeepLinkData({ url: null });
  };

  return { deepLinkData, clearDeepLink };
};

/**
 * Extract reset code from Firebase password reset URL
 */
export const extractResetCodeFromUrl = (url: string): string | null => {
  try {
    const parsedUrl = new URL(url);
    return parsedUrl.searchParams.get('oobCode');
  } catch (error) {
    console.error('Error extracting reset code:', error);
    return null;
  }
};