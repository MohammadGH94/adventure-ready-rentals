import { Platform } from 'react-native';
import { signInWithGoogleMobile } from './google-auth-mobile'; // We'll create this for mobile
import { signInWithGoogleWeb } from './google-auth-web';

export interface GoogleSignInResult {
  user: any | null;
  error?: string;
}

export async function signInWithGoogle(): Promise<GoogleSignInResult> {
  if (Platform.OS === 'web') {
    return signInWithGoogleWeb();
  } else {
    // For mobile (when you test on device)
    return signInWithGoogleMobile();
  }
}