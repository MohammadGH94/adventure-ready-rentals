import { confirmPasswordReset, sendPasswordResetEmail, verifyPasswordResetCode } from 'firebase/auth';
import { auth } from '../conf/firebaseConfig';

export interface PasswordResetResult {
  success: boolean;
  error?: string;
}

/**
 * Send password reset email
 */
export const sendPasswordReset = async (email: string): Promise<PasswordResetResult> => {
  try {
    if (!email.trim()) {
      throw new Error('Email is required');
    }

    if (!email.includes('@')) {
      throw new Error('Please enter a valid email address');
    }

    await sendPasswordResetEmail(auth, email);
    
    return { success: true };
  } catch (error: any) {
    console.error('Error sending password reset email:', error);
    
    let errorMessage = 'Failed to send password reset email';
    
    // Handle specific Firebase error codes
    switch (error.code) {
      case 'auth/user-not-found':
        errorMessage = 'No account found with this email address';
        break;
      case 'auth/invalid-email':
        errorMessage = 'Invalid email address';
        break;
      case 'auth/too-many-requests':
        errorMessage = 'Too many requests. Please try again later';
        break;
      default:
        errorMessage = error.message || errorMessage;
    }
    
    return { success: false, error: errorMessage };
  }
};

/**
 * Verify password reset code
 */
export const verifyResetCode = async (code: string): Promise<PasswordResetResult & { email?: string }> => {
  try {
    if (!code.trim()) {
      throw new Error('Reset code is required');
    }

    const email = await verifyPasswordResetCode(auth, code);
    
    return { success: true, email };
  } catch (error: any) {
    console.error('Error verifying reset code:', error);
    
    let errorMessage = 'Invalid or expired reset code';
    
    switch (error.code) {
      case 'auth/invalid-action-code':
        errorMessage = 'Invalid reset code';
        break;
      case 'auth/expired-action-code':
        errorMessage = 'Reset code has expired';
        break;
      default:
        errorMessage = error.message || errorMessage;
    }
    
    return { success: false, error: errorMessage };
  }
};

/**
 * Confirm password reset with new password
 */
export const confirmPasswordResetWithCode = async (
  code: string, 
  newPassword: string
): Promise<PasswordResetResult> => {
  try {
    if (!code.trim()) {
      throw new Error('Reset code is required');
    }

    if (!newPassword.trim()) {
      throw new Error('New password is required');
    }

    if (newPassword.length < 6) {
      throw new Error('Password must be at least 6 characters long');
    }

    await confirmPasswordReset(auth, code, newPassword);
    
    return { success: true };
  } catch (error: any) {
    console.error('Error confirming password reset:', error);
    
    let errorMessage = 'Failed to reset password';
    
    switch (error.code) {
      case 'auth/invalid-action-code':
        errorMessage = 'Invalid reset code';
        break;
      case 'auth/expired-action-code':
        errorMessage = 'Reset code has expired';
        break;
      case 'auth/weak-password':
        errorMessage = 'Password is too weak';
        break;
      default:
        errorMessage = error.message || errorMessage;
    }
    
    return { success: false, error: errorMessage };
  }
};