import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Button,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';

import { useAuth } from '../contexts/AuthContext';
import { sendVerificationEmail, signOutUser } from '../services/auth';
import { getUser } from '../services/firestoreService';
import { User as UserProfile } from '../types/schemas';

type ProfileState = {
  data: UserProfile | null;
  isLoading: boolean;
  error: string | null;
};

const initialState: ProfileState = {
  data: null,
  isLoading: false,
  error: null
};

const ProfileScreen = () => {
  const { user } = useAuth();
  const [{ data: profile, isLoading, error }, setProfileState] = useState<ProfileState>(initialState);
  const [isSendingVerification, setIsSendingVerification] = useState(false);

  useEffect(() => {
    let isCancelled = false;

    const loadProfile = async () => {
      if (!user?.uid) {
        setProfileState(initialState);
        return;
      }

      setProfileState(prev => ({ ...prev, isLoading: true, error: null }));

      try {
        const profileData = await getUser(user.uid);

        if (!isCancelled) {
          setProfileState({
            data: profileData,
            isLoading: false,
            error: profileData ? null : 'No additional profile details found yet.'
          });
        }
      } catch (profileError) {
        if (!isCancelled) {
          setProfileState({
            data: null,
            isLoading: false,
            error: 'Unable to load your profile right now.'
          });
        }
      }
    };

    loadProfile();

    return () => {
      isCancelled = true;
    };
  }, [user?.uid]);

  const handleSignOut = async () => {
    try {
      await signOutUser();
    } catch (signOutError) {
      Alert.alert('Sign out failed', 'Please try again in a moment.');
    }
  };

  const fullNameFromProfile = [profile?.firstName, profile?.lastName]
    .filter((part) => !!part && part.trim().length > 0)
    .join(' ');
  const name = fullNameFromProfile || profile?.name || user?.displayName || 'Anonymous user';
  const email = profile?.email ?? user?.email ?? 'Email not available';
  const emailVerified = user?.emailVerified ?? false;
  const phoneNumber = profile?.phoneNumber ?? 'Phone number not provided';
  const addressSegments = [profile?.city, profile?.stateProvince, profile?.country]
    .filter((segment) => !!segment && segment.trim().length > 0);
  const address = addressSegments.length > 0 ? addressSegments.join(', ') : 'Address not set';
  const postalCode = profile?.postalCode ?? '—';
  const memberSince = profile?.createdAt ? profile.createdAt.toDate().toLocaleDateString() : '—';
  const userTypeLabel = profile?.userType === 'business' ? 'Business' : 'Individual';
  const verificationStatus = profile?.isVerified ? 'Verified' : 'Not verified yet';
  const profileBio = profile?.profileBio ?? 'Add a short bio to personalize your profile.';
  const paymentMethods = profile?.paymentMethodIds?.length
    ? profile.paymentMethodIds.join(', ')
    : 'No payment methods linked yet.';
  const payoutMethod = profile?.payoutMethodId ?? 'No payout method configured.';
  const businessName = profile?.businessName ?? '—';
  const businessLicense = profile?.businessLicense ?? '—';
  const taxId = profile?.taxId ?? '—';
  const governmentIdImage = profile?.governmentIdImage ?? 'Not uploaded';
  const voidCheque = profile?.voidCheque ?? 'Not uploaded';
  const institutionNumber = profile?.institutionNumber ?? '—';
  const transitNumber = profile?.transitNumber ?? '—';
  const accountNumber = profile?.accountNumber ?? '—';
  const avatarInitial = name.trim().charAt(0).toUpperCase();

  if (!user) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.centerContent}>
          <Text style={styles.heading}>Welcome!</Text>
          <Text style={styles.subtitle}>Sign in from the Home tab to view your profile details.</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      {isLoading ? (
        <View style={styles.centerContent}>
          <ActivityIndicator size="large" color="#1f7a8c" />
          <Text style={styles.loadingText}>Loading your profile…</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.container}>
          <View style={styles.avatarContainer}>
            <View style={styles.avatarPlaceholder}>
              <Text style={styles.avatarText}>{avatarInitial}</Text>
            </View>
            <Text style={styles.heading}>{name}</Text>
            <Text style={styles.subtitle}>{email}</Text>
          </View>

          {error && (
            <View style={styles.feedbackBanner}>
              <Text style={styles.feedbackText}>{error}</Text>
            </View>
          )}

          {!emailVerified && (
            <View style={styles.feedbackBannerWarning}>
              <Text style={styles.feedbackTextStrong}>Email verification pending</Text>
              <Text style={styles.feedbackTextMuted}>
                Confirm your email to receive booking alerts and publish listings. We can resend the link if needed.
              </Text>
              <TouchableOpacity
                style={styles.verifyButton}
                onPress={async () => {
                  try {
                    setIsSendingVerification(true);
                    await sendVerificationEmail();
                    Alert.alert('Verification email sent', 'Check your inbox and follow the link to verify.');
                  } catch (sendError: any) {
                    Alert.alert('Unable to send email', sendError.message || 'Please try again soon.');
                  } finally {
                    setIsSendingVerification(false);
                  }
                }}
                disabled={isSendingVerification}
              >
                <Text style={styles.verifyButtonText}>
                  {isSendingVerification ? 'Sending...' : 'Resend verification'}
                </Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={styles.bioCard}>
            <Text style={styles.sectionHeading}>About</Text>
            <Text style={styles.bioText}>{profileBio}</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.label}>User Type</Text>
            <Text style={styles.value}>{userTypeLabel}</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.label}>Verification</Text>
            <Text style={styles.value}>{verificationStatus}</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.label}>Member Since</Text>
            <Text style={styles.value}>{memberSince}</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.label}>Email</Text>
            <Text style={styles.value}>{email}</Text>
            <Text style={styles.subtleValue}>Status: {emailVerified ? 'Verified' : 'Awaiting verification'}</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.label}>Phone</Text>
            <Text style={styles.value}>{phoneNumber}</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.label}>Address</Text>
            <Text style={styles.value}>{address}</Text>
            <Text style={styles.subtleValue}>Postal Code: {postalCode}</Text>
          </View>

          {profile?.userType === 'business' && (
            <View style={styles.infoCard}>
              <Text style={styles.label}>Business Details</Text>
              <Text style={styles.value}>Name: {businessName}</Text>
              <Text style={styles.value}>License: {businessLicense}</Text>
              <Text style={styles.value}>Tax ID: {taxId}</Text>
            </View>
          )}

          <View style={styles.infoCard}>
            <Text style={styles.label}>Payment Methods</Text>
            <Text style={styles.value}>{paymentMethods}</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.label}>Payout Method</Text>
            <Text style={styles.value}>{payoutMethod}</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.label}>Banking Details</Text>
            <Text style={styles.value}>Institution #: {institutionNumber}</Text>
            <Text style={styles.value}>Transit #: {transitNumber}</Text>
            <Text style={styles.value}>Account #: {accountNumber}</Text>
          </View>

          <View style={styles.infoCard}>
            <Text style={styles.label}>Compliance</Text>
            <Text style={styles.value}>Government ID: {governmentIdImage}</Text>
            <Text style={styles.value}>Void Cheque: {voidCheque}</Text>
          </View>

          <View style={styles.buttonContainer}>
            <Button title="Sign Out" color="#d9534f" onPress={handleSignOut} />
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
};

export default ProfileScreen;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#fff',
  },
  container: {
    padding: 24,
    gap: 16,
  },
  centerContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  avatarContainer: {
    alignItems: 'center',
    gap: 8,
  },
  avatarPlaceholder: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: '#cbd5f5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 36,
    fontWeight: '700',
    color: '#1f2937',
  },
  heading: {
    fontSize: 24,
    fontWeight: '600',
    color: '#1f2937',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    color: '#4b5563',
    textAlign: 'center',
  },
  sectionHeading: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 8,
  },
  feedbackBanner: {
    backgroundColor: '#fef3c7',
    borderRadius: 12,
    padding: 12,
  },
  feedbackText: {
    color: '#92400e',
    fontSize: 14,
    textAlign: 'center',
  },
  feedbackBannerWarning: {
    backgroundColor: '#102f43',
    borderRadius: 16,
    padding: 18,
    gap: 10,
    borderWidth: 1,
    borderColor: '#1c4a63',
  },
  feedbackTextStrong: {
    color: '#f0f7ff',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'left',
  },
  feedbackTextMuted: {
    color: '#c9dfea',
    fontSize: 14,
    lineHeight: 20,
  },
  verifyButton: {
    alignSelf: 'flex-start',
    backgroundColor: '#23b585',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 999,
  },
  verifyButtonText: {
    color: '#0b1924',
    fontSize: 14,
    fontWeight: '600',
  },
  infoCard: {
    backgroundColor: '#f3f4f6',
    borderRadius: 16,
    padding: 16,
    gap: 4,
  },
  label: {
    fontSize: 12,
    textTransform: 'uppercase',
    color: '#6b7280',
    letterSpacing: 0.6,
  },
  value: {
    fontSize: 16,
    color: '#111827',
    fontWeight: '500',
  },
  subtleValue: {
    fontSize: 14,
    color: '#4b5563',
  },
  bioCard: {
    backgroundColor: '#e5e7eb',
    borderRadius: 16,
    padding: 16,
    gap: 8,
  },
  bioText: {
    fontSize: 16,
    color: '#374151',
    lineHeight: 22,
  },
  buttonContainer: {
    marginTop: 16,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#4b5563',
  },
});
