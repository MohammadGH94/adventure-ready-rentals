import { useDeepLink } from '@/app/services/deep-links';
import { EquipmentForm } from '@/components/equip-form';
import { PasswordResetScreen } from '@/components/password-reset-screen';
import { useRouter } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';

import { SignInForm } from '../../components/sign-in-form';
import { SignUpForm } from '../../components/sign-up-form';
import { useAuth } from '../contexts/AuthContext';
import { sendVerificationEmail, signOutUser } from '../services/auth';

const FEATURE_CARDS = [
  {
    title: 'List Your Gear',
    description: 'Turn that spare tent, ski setup, or hiking pack into extra income when you are not using it.'
  },
  {
    title: 'Discover Local Adventures',
    description: 'Find high-quality camping, hiking, and skiing gear from outdoor lovers near you.'
  },
  {
    title: 'Borrow With Confidence',
    description: 'Verified profiles, secure payments, and clear policies keep every rental smooth and friendly.'
  }
];

const CATEGORY_CARDS = [
  {
    title: 'Backpacking & Hiking',
    detail: 'Ultralight tents, trekking poles, GPS trackers, & more for your next trail mission.'
  },
  {
    title: 'Ski & Snowboard',
    detail: 'Skis, splitboards, avalanche safety kits, and layers for winter stoke.'
  },
  {
    title: 'Camping Essentials',
    detail: 'Family tents, camp kitchens, rooftop boxes, and cozy sleeping systems.'
  }
];

const AppContent = () => {
  const router = useRouter();
  const { user, loading } = useAuth();
  const { deepLinkData, clearDeepLink } = useDeepLink();
  
  const [showSignIn, setShowSignIn] = useState(false);
  const [showSignUp, setShowSignUp] = useState(false);
  const [showPasswordReset, setShowPasswordReset] = useState(false);
  const [showEquipmentForm, setShowEquipmentForm] = useState(false);
  const [isSendingVerification, setIsSendingVerification] = useState(false);

  const welcomeName = useMemo(() => {
    if (!user) return '';
    return user.displayName?.split(' ')[0] || user.email || 'Explorer';
  }, [user]);

  // Handle deep link for password reset
  useEffect(() => {
    if (deepLinkData.mode === 'resetPassword' && deepLinkData.resetCode) {
      console.log('Password reset deep link detected');
      setShowPasswordReset(true);
      // Close other modals
      setShowSignIn(false);
      setShowSignUp(false);
    }
  }, [deepLinkData]);

  const handlePasswordResetSuccess = () => {
    setShowPasswordReset(false);
    clearDeepLink();
    Alert.alert(
      'Password Reset Complete',
      'Your password has been reset successfully. Please sign in with your new password.',
      [
        {
          text: 'Sign In',
          onPress: () => setShowSignIn(true)
        }
      ]
    );
  };

  const handlePasswordResetCancel = () => {
    setShowPasswordReset(false);
    clearDeepLink();
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <StatusBar style="light" />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading your trailhead...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // Show password reset screen if deep link detected
  if (showPasswordReset && deepLinkData.resetCode) {
    return (
      <PasswordResetScreen
        resetCode={deepLinkData.resetCode}
        onSuccess={handlePasswordResetSuccess}
        onCancel={handlePasswordResetCancel}
      />
    );
  }

  const resendVerification = async () => {
    try {
      setIsSendingVerification(true);
      await sendVerificationEmail();
      Alert.alert('Email sent', 'Check your inbox for the verification link.');
    } catch (error: any) {
      Alert.alert('Unable to send email', error.message || 'Please try again shortly.');
    } finally {
      setIsSendingVerification(false);
    }
  };

  if (user) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <StatusBar style="light" />
        <ScrollView contentContainerStyle={styles.scrollContent}>
          {!user.emailVerified && (
            <View style={styles.verificationBanner}>
              <View style={styles.bannerTextBlock}>
                <Text style={styles.bannerTitle}>Verify your email</Text>
                <Text style={styles.bannerCopy}>
                  Confirm your address to list gear and receive booking updates. Haven&apos;t received it? Resend below.
                </Text>
              </View>
              <TouchableOpacity
                style={[styles.ctaButton, styles.bannerButton]}
                onPress={resendVerification}
                disabled={isSendingVerification}
              >
                <Text style={styles.bannerButtonText}>
                  {isSendingVerification ? 'Sending...' : 'Resend link'}
                </Text>
              </TouchableOpacity>
            </View>
          )}

          <View style={styles.hero}>
            <Text style={styles.heroEyebrow}>Welcome back, {welcomeName}.</Text>
            <Text style={styles.heroTitle}>Share the stoke. Fuel someone&apos;s next adventure.</Text>
            <Text style={styles.heroSubtitle}>
              Post your hiking, skiing, and camping gear or find the perfect setup for your own trip. Keep outdoor
              adventures accessible for everyone in the community.
            </Text>
            <View style={styles.heroActions}>
              <TouchableOpacity style={[styles.ctaButton, styles.primaryCta]} onPress={() => setShowEquipmentForm(true)}>
                <Text style={styles.primaryCtaText}>List My Gear</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.ctaButton, styles.secondaryCta]}
                onPress={() => router.push('/explore')}
              >
                <Text style={styles.secondaryCtaText}>Browse Available Gear</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Popular categories renters are searching for</Text>
            <View style={styles.cardGrid}>
              {CATEGORY_CARDS.map((card) => (
                <View key={card.title} style={styles.categoryCard}>
                  <Text style={styles.cardTitle}>{card.title}</Text>
                  <Text style={styles.cardDescription}>{card.detail}</Text>
                </View>
              ))}
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Make the most of Cirk</Text>
            <View style={styles.cardGrid}>
              <View style={styles.featureCard}>
                <Text style={styles.cardTitle}>Keep your listings fresh</Text>
                <Text style={styles.cardDescription}>
                  Upload crisp photos, add availability notes, and respond quickly to booking requests to stay at the
                  top of search results.
                </Text>
              </View>
              <View style={styles.featureCard}>
                <Text style={styles.cardTitle}>Trust & safety</Text>
                <Text style={styles.cardDescription}>
                  We handle secure payments and reminders, so you can focus on getting outside while protecting your gear.
                </Text>
              </View>
              <View style={styles.featureCard}>
                <Text style={styles.cardTitle}>Stay in sync</Text>
                <Text style={styles.cardDescription}>
                  Track upcoming rentals, check-in instructions, and payouts from the new profile tab anytime.
                </Text>
              </View>
            </View>
          </View>

          <TouchableOpacity style={styles.signOutButton} onPress={() => signOutUser()}>
            <Text style={styles.signOutText}>Sign Out</Text>
          </TouchableOpacity>
        </ScrollView>

        <EquipmentForm visible={showEquipmentForm} onClose={() => setShowEquipmentForm(false)} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.hero}>
          <Text style={styles.heroEyebrow}>Outdoor gear, shared by locals</Text>
          <Text style={styles.heroTitle}>Rent hiking, skiing, and camping gear from people nearby.</Text>
          <Text style={styles.heroSubtitle}>
            Skip expensive retail rentals. Cirk puts premium outdoor equipment at your fingertips and helps owners keep
            their gear in motion.
          </Text>
          <View style={styles.heroActions}>
            <TouchableOpacity style={[styles.ctaButton, styles.primaryCta]} onPress={() => setShowSignUp(true)}>
              <Text style={styles.primaryCtaText}>Create a free account</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.ctaButton, styles.secondaryCta]} onPress={() => setShowSignIn(true)}>
              <Text style={styles.secondaryCtaText}>I already have an account</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Why the community loves Cirk</Text>
          <View style={styles.cardGrid}>
            {FEATURE_CARDS.map((card) => (
              <View key={card.title} style={styles.featureCard}>
                <Text style={styles.cardTitle}>{card.title}</Text>
                <Text style={styles.cardDescription}>{card.description}</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Plan your next adventure</Text>
          <View style={styles.cardGrid}>
            {CATEGORY_CARDS.map((card) => (
              <View key={card.title} style={styles.categoryCard}>
                <Text style={styles.cardTitle}>{card.title}</Text>
                <Text style={styles.cardDescription}>{card.detail}</Text>
                <Text style={styles.cardHint}>Popular with weekend explorers</Text>
              </View>
            ))}
          </View>
        </View>

        <View style={styles.sectionAlt}>
          <Text style={styles.sectionTitleAlt}>Ready to share your gear?</Text>
          <Text style={styles.sectionCopyAlt}>
            Snap a few photos, set your availability, and publish listings in minutes. We take care of secure payments,
            reminders, and renter verification.
          </Text>
          <TouchableOpacity style={[styles.ctaButton, styles.primaryCta]} onPress={() => setShowSignUp(true)}>
            <Text style={styles.primaryCtaText}>Start listing today</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <SignInForm
        visible={showSignIn}
        onClose={() => setShowSignIn(false)}
        onSwitchToSignUp={() => {
          setShowSignIn(false);
          setShowSignUp(true);
        }}
      />

      <SignUpForm
        visible={showSignUp}
        onClose={() => setShowSignUp(false)}
        onSwitchToSignIn={() => {
          setShowSignUp(false);
          setShowSignIn(true);
        }}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#0b1924',
  },
  scrollContent: {
    padding: 24,
    paddingBottom: 48,
    gap: 32,
  },
  hero: {
    backgroundColor: '#102c3d',
    borderRadius: 24,
    padding: 28,
    gap: 16,
    borderWidth: 1,
    borderColor: '#1f3f52',
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 8 },
  },
  heroEyebrow: {
    color: '#88d2c0',
    fontSize: 14,
    letterSpacing: 1,
    textTransform: 'uppercase',
    fontWeight: '600',
  },
  heroTitle: {
    color: '#f8fbff',
    fontSize: 28,
    fontWeight: '700',
    lineHeight: 34,
  },
  heroSubtitle: {
    color: '#d0e4f2',
    fontSize: 16,
    lineHeight: 22,
  },
  heroActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  ctaButton: {
    paddingVertical: 14,
    paddingHorizontal: 18,
    borderRadius: 12,
    borderWidth: 1,
  },
  primaryCta: {
    backgroundColor: '#23b585',
    borderColor: '#23b585',
  },
  primaryCtaText: {
    color: '#0b1924',
    fontSize: 16,
    fontWeight: '600',
  },
  secondaryCta: {
    backgroundColor: 'transparent',
    borderColor: '#3a5569',
  },
  secondaryCtaText: {
    color: '#e0f2ff',
    fontSize: 16,
    fontWeight: '600',
  },
  section: {
    backgroundColor: '#132f40',
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: '#1f475f',
    gap: 18,
  },
  sectionAlt: {
    backgroundColor: '#102c3d',
    borderRadius: 20,
    padding: 24,
    gap: 16,
    alignItems: 'flex-start',
    borderWidth: 1,
    borderColor: '#1f3f52',
  },
  sectionTitle: {
    color: '#f0f7ff',
    fontSize: 22,
    fontWeight: '700',
    lineHeight: 28,
  },
  sectionTitleAlt: {
    color: '#f0f7ff',
    fontSize: 24,
    fontWeight: '700',
  },
  sectionCopyAlt: {
    color: '#c9dfea',
    fontSize: 16,
    lineHeight: 22,
  },
  verificationBanner: {
    backgroundColor: '#1b3f4e',
    borderRadius: 18,
    padding: 20,
    borderWidth: 1,
    borderColor: '#2d5c70',
    gap: 12,
  },
  bannerTextBlock: {
    gap: 6,
  },
  bannerTitle: {
    color: '#f8fbff',
    fontSize: 18,
    fontWeight: '600',
  },
  bannerCopy: {
    color: '#c9dfea',
    fontSize: 14,
    lineHeight: 20,
  },
  bannerButton: {
    alignSelf: 'flex-start',
    backgroundColor: '#23b585',
    borderColor: '#23b585',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  bannerButtonText: {
    color: '#0b1924',
    fontSize: 15,
    fontWeight: '600',
  },
  cardGrid: {
    gap: 16,
  },
  featureCard: {
    backgroundColor: '#17394d',
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: '#215068',
    gap: 8,
  },
  categoryCard: {
    backgroundColor: '#17394d',
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: '#215068',
    gap: 8,
  },
  cardTitle: {
    color: '#f0f7ff',
    fontSize: 18,
    fontWeight: '600',
  },
  cardDescription: {
    color: '#c9dfea',
    fontSize: 15,
    lineHeight: 21,
  },
  cardHint: {
    color: '#88d2c0',
    fontSize: 13,
  },
  signOutButton: {
    alignSelf: 'center',
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#3a5569',
  },
  signOutText: {
    color: '#c9dfea',
    fontSize: 15,
    fontWeight: '600',
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
    backgroundColor: '#0b1924',
  },
  loadingText: {
    color: '#c9dfea',
    fontSize: 16,
  },
});

export default AppContent;
