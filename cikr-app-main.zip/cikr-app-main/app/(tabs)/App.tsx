import { EquipmentForm } from '@/components/equip-form';
import { HomeScreen } from '@/components/home';
import { StatusBar } from 'expo-status-bar';
import React, { useState } from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';

export default function App() {
  const [modalVisible, setModalVisible] = useState(false);

  const handleAddEquipment = () => {
    setModalVisible(true);
  };

  const handleCloseModal = () => {
    setModalVisible(false);
  };

  return (
    <SafeAreaView style={styles.container}>
      <HomeScreen onAddEquipment={handleAddEquipment} />
      
      <EquipmentForm 
        visible={modalVisible} 
        onClose={handleCloseModal} 
      />

      <StatusBar style="auto" />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f4f8',
  },
});