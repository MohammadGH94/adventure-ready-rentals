import { Alert } from 'react-native';
import { Equipment } from '../types/schemas';

export const validateEquipmentForm = (formData: Equipment): boolean => {
  if (!formData.title.trim()) {
    Alert.alert('Error', 'Title is required');
    return false;
  }
  if (!formData.description.trim()) {
    Alert.alert('Error', 'Description is required');
    return false;
  }
  if (!formData.category.trim()) {
    Alert.alert('Error', 'Category is required');
    return false;
  }
  if (!formData.pricePerDay.toString().trim() || isNaN(Number(formData.pricePerDay)) || Number(formData.pricePerDay) <= 0) {
    Alert.alert('Error', 'Please enter a valid price per day');
    return false;
  }
  if (!formData.location.trim()) {
    Alert.alert('Error', 'Location is required');
    return false;
  }
  return true;
};