import { configureStore } from '@reduxjs/toolkit';

// Example slice import (create this next)
// import exampleReducer from './features/exampleSlice';

export const store = configureStore({
  reducer: {
    // example: exampleReducer,
    // add more slices here
  },
});

// Types for use throughout the app
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;