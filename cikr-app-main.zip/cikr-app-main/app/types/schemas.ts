import { Timestamp } from 'firebase/firestore';

export type UserType = 'individual' | 'business';

export interface User {
  id: string;
  email: string;
  userType: UserType;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  phoneNumber: string;
  profileBio: string;
  city: string;
  stateProvince: string;
  country: string;
  postalCode: string;
  governmentIdImage?: string | null;
  isVerified: boolean;
  paymentMethodIds: string[];
  voidCheque?: string | null;
  institutionNumber?: string | null;
  transitNumber?: string | null;
  accountNumber?: string | null;
  payoutMethodId?: string | null;
  businessName?: string | null;
  businessLicense?: string | null;
  taxId?: string | null;
  profileImageUrl?: string;
  name?: string;
  createdAt: Timestamp;
}

export interface Equipment {
  id: string;
  title: string;
  description: string;
  category: string;
  pricePerDay: number;
  ownerId: string;
  imageUrls: string[];
  location: string;
  availability: boolean;
  listedAt: Timestamp;
}

export interface Booking {
  id: string;
  equipmentId: string;
  renterId: string;
  ownerId: string;
  startDate: Timestamp;
  endDate: Timestamp;
  totalPrice: number;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  createdAt: Timestamp;
}
